import 'vuetify/styles'

import { createVuetify } from 'vuetify' // Replaces new Vuetify(...)


const vuetify = createVuetify({
    
})

export default vuetify;