<template>
    <p>componet my header</p>
</template>

<script setup>
console.log('componet my header');
import {onMounted, ref} from 'vue';


/////////////////////////////
    // before route leave
// onBeforeRouteLeave(async(to,from,next) => {
// // check if the form not saved
// if(saved.value) return next();
// const confirm = await ConfirmModal.fire({
// title: 'هل أنت متأكد من الخروج من الإستبيان بدون الحفظ 🥴',
// icon:"warning"
// })
// if (confirm.isConfirmed) next();
// else next(false)
// })
////////////////////////////

</script>
